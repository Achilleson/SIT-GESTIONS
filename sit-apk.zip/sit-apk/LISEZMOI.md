# SIT-Gestion — Fabriquer l'APK (gratuit, sans rien installer)

1. Créez un compte gratuit sur https://github.com (si besoin).
2. Cliquez « + » > « New repository », nom : `sit-gestion`, laissez-le Public ou Private, créez-le.
3. Sur la page du dépôt : « uploading an existing file » et glissez TOUT le contenu de ce dossier
   (y compris le dossier caché `.github`). Validez avec « Commit changes ».
4. Onglet « Actions » > « Construire l'APK SIT-Gestion » > « Run workflow ». Attendez 5 à 8 minutes.
5. Ouvrez l'exécution terminée, section « Artifacts », téléchargez « SIT-Gestion-APK » (zip contenant app-debug.apk).

## Installer sans internet
- Copiez `app-debug.apk` sur le téléphone (câble USB, Bluetooth, carte SD, Xender/SHAREit).
- Ouvrez-le, autorisez « Sources inconnues » si demandé, puis installez. L'application marche ensuite 100 % hors connexion.
- Ordinateur : ouvrez `www/index.html` dans Chrome ou Edge (hors connexion), ou installez-la comme application via l'icône « Installer » dans la barre d'adresse.
